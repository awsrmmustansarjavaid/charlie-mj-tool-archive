/* Charlie MJ Tool Archive — additive portable JSON persistence layer.
 * Uses a user-authorized folder handle (File System Access API) and optionally
 * Native Messaging. Never writes into the packaged extension directory.
 */
(() => {
  'use strict';
  const DB='CharlieMJPortableHandles', STORE='handles', HOST='com.charliemj.toolarchive';
  let nativePort=null;
  const slug=s=>String(s||'uncategorized').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,64)||'uncategorized';
  const safe=s=>String(s||'').replace(/[\\:*?"<>|]/g,'-').replace(/\.\./g,'-').slice(0,100)||'category';
  function openHandleDb(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
  async function storeHandle(handle){const db=await openHandleDb();await new Promise((res,rej)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(handle,'portableRoot');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
  async function getHandle(){const db=await openHandleDb();return new Promise((res,rej)=>{const r=db.transaction(STORE).objectStore(STORE).get('portableRoot');r.onsuccess=()=>res(r.result||null);r.onerror=()=>rej(r.error)})}
  async function clearHandle(){const db=await openHandleDb();await new Promise((res,rej)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete('portableRoot');tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
  async function permission(h,write=true){const opts={mode:write?'readwrite':'read'};if(await h.queryPermission(opts)==='granted')return true;return await h.requestPermission(opts)==='granted'}
  function makeFiles(tools,remote,settings,categories,collections,manualBackup=false){
    const now=new Date(),stamp=now.toISOString(),files={};
    const nodes=Array.isArray(categories)?categories:[];const byId=new Map(nodes.map(n=>[n.id,n]));
    const usedPaths=new Set();const pathFor=n=>{const chain=[];let c=n;while(c){chain.unshift(c);c=c.parentId?byId.get(c.parentId):null}const root=chain[0];let path=chain.length===1?`database/categories/${slug(root.name)}.json`:`database/subcategories/${chain.slice(0,-1).map(x=>slug(x.name)).join('/')}/${slug(n.name)}.json`;if(usedPaths.has(path)){const parts=path.split('/'),file=parts.pop(),stem=file.replace(/\.json$/,'');parts.push(`${stem}-${String(n.id||'').slice(-6)||'extra'}.json`);path=parts.join('/')}usedPaths.add(path);return path};
    const index=[];
    for(const n of nodes){const list=(tools||[]).filter(t=>(t.subcategoryId||t.categoryId)===n.id || (!t.categoryId && String(t.category||'').toLowerCase()===String(n.name).toLowerCase()));const parent=n.parentId?byId.get(n.parentId):null;const file=pathFor(n);files[file]=JSON.stringify({version:'6.1.3',app:'Charlie MJ Tool Archive',format:'category-collection',category:n,parentCategory:parent,recordCount:list.length,tools:list,exportedAt:stamp},null,2);index.push({id:n.id,name:n.name,parentId:n.parentId||null,path:file,recordCount:list.length,updatedAt:stamp})}
    const portableSettings={...(settings||{})};delete portableSettings.portableNativePath;delete portableSettings.portableNativeEnabled;delete portableSettings.portableFolderFallback;const profile={version:'6.1.3',app:'Charlie MJ Tool Archive',exportedAt:stamp,localLibrary:tools||[],remoteLibrary:remote||[],settings:portableSettings,collections:collections||[],categories:nodes,toolCount:(tools||[]).length,categoryCount:nodes.length};
    files['profile-data.json']=JSON.stringify(profile,null,2);
    files['database/category-index.json']=JSON.stringify({version:'6.1.3',categories:index},null,2);
    files['database/database-manifest.json']=JSON.stringify({version:'6.1.3',app:'Charlie MJ Tool Archive',updatedAt:stamp,toolCount:profile.toolCount,categoryCount:nodes.length,files:Object.keys(files)},null,2);
    files['database/collections.json']=JSON.stringify({collections:collections||[],updatedAt:stamp},null,2);
    files['database/legacy-local-library.json']=JSON.stringify({version:'5.0.0',app:'Charlie MJ Tool Archive',tools:tools||[]},null,2);
    if(manualBackup){files[`backup/profile-${stamp.replace(/[:.]/g,'-')}.json`]=JSON.stringify(profile,null,2);files['backup/latest-backup.json']=JSON.stringify(profile,null,2)}
    return files;
  }
  async function writeDirectory(root,files){
    // Remove category JSON files that disappeared after a category rename/deletion.
    try{const dbDir=await root.getDirectoryHandle('database');const oldFile=await dbDir.getFileHandle('category-index.json');const old=JSON.parse(await (await oldFile.getFile()).text());const next=JSON.parse(files['database/category-index.json']||'{"categories":[]}');const keep=new Set((next.categories||[]).map(x=>x.path));for(const item of old.categories||[]){if(item.path&&!keep.has(item.path)){const parts=item.path.split('/');let dir=root;try{for(const part of parts.slice(0,-1))dir=await dir.getDirectoryHandle(safe(part));await dir.removeEntry(safe(parts.at(-1)))}catch{}}}}catch{}
    for(const [path,content] of Object.entries(files)){const parts=path.split('/');let dir=root;for(const part of parts.slice(0,-1))dir=await dir.getDirectoryHandle(safe(part),{create:true});const fh=await dir.getFileHandle(safe(parts.at(-1)),{create:true});const w=await fh.createWritable();await w.write(content);await w.close()}
  }
  function nativeRequest(port,message){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Native helper timed out')),20000);const onMessage=m=>{clearTimeout(timer);port.onMessage.removeListener(onMessage);if(m?.ok)resolve(m);else reject(new Error(m?.error||'Native helper request failed'))};port.onMessage.addListener(onMessage);port.postMessage(message)})}
  async function nativeWrite(rootPath,files){if(!nativePort)nativePort=chrome.runtime.connectNative(HOST);const port=nativePort;try{let written=0;for(const [path,content] of Object.entries(files)){if(content.length<150000){await nativeRequest(port,{action:'writeFile',root:rootPath,path,content})}else{await nativeRequest(port,{action:'writeFileStart',root:rootPath,path});const chars=Array.from(content);for(let i=0;i<chars.length;i+=150000)await nativeRequest(port,{action:'writeFileChunk',root:rootPath,path,chunk:chars.slice(i,i+150000).join('')});await nativeRequest(port,{action:'writeFileEnd',root:rootPath,path})}written++}return {ok:true,written}}catch(e){try{nativePort?.disconnect()}catch{}nativePort=null;throw e}}
  async function getDataDirectory(root,create=false){
    // New configuration selects the extension root; older configurations that selected user-data directly remain readable.
    try{await root.getFileHandle('manifest.json');return await root.getDirectoryHandle('user-data',{create})}catch(e){if(e?.name==='NotFoundError')return root;throw e}
  }
  async function sync({tools,remote=[],settings={},categories=[],collections=[],manualBackup=false}={}){
    const nativePath=String(settings.portableNativePath||'').trim();const nativeEnabled=!!(settings.portableNativeEnabled&&nativePath);const handle=await getHandle();
    if(!nativeEnabled&&!handle){await chrome.storage.local.set({cmjPortableSync:{status:'not-configured',lastSync:0,fileCount:0,error:''}});return {ok:false,configured:false,fileCount:0}}
    const saved=await chrome.storage.local.get('cmjPortableSync');const today=new Date().toISOString().slice(0,10);const createBackup=manualBackup||(settings.portableKeepBackups!==false&&saved.cmjPortableSync?.lastBackupDate!==today);const files=makeFiles(tools,remote,settings,categories,collections,createBackup);const errors=[],methods=[];
    if(nativeEnabled){try{await nativeWrite(nativePath,files);methods.push('native');await log(`Native folder synchronized (${Object.keys(files).length} files)`)}catch(e){errors.push(`Native helper: ${e.message}`);await log(`Native helper error: ${e.message}`,'error');if(!settings.portableFolderFallback&&!handle){await chrome.storage.local.set({cmjPortableSync:{status:'native-error',lastSync:Date.now(),error:e.message}});throw e}}}
    if(handle&&(!nativeEnabled||methods.includes('native')||settings.portableFolderFallback!==false)){try{if(await permission(handle)){const dataRoot=await getDataDirectory(handle,true);await writeDirectory(dataRoot,files);methods.push('folder');await log(`Extension user-data synchronized (${Object.keys(files).length} files)`)}}catch(e){errors.push(`Browser folder: ${e.message}`);await log(`Portable folder error: ${e.message}`,'error')}}
    if(methods.length){const status=methods.length===2?'synced-both':errors.length?'partial':'synced-'+methods[0];const error=errors.join(' | ');await chrome.storage.local.set({cmjPortableSync:{status,lastSync:Date.now(),lastBackupDate:createBackup?today:(saved.cmjPortableSync?.lastBackupDate||''),fileCount:Object.keys(files).length,error}});return {ok:errors.length===0,partial:errors.length>0,method:methods.join('+'),fileCount:Object.keys(files).length,error}}
    const error=errors.join(' | ')||'No portable destination is available';await chrome.storage.local.set({cmjPortableSync:{status:'sync-error',lastSync:Date.now(),fileCount:Object.keys(files).length,error}});throw new Error(error);
  }
  async function readFolderProfile(){
    const handle=await getHandle();if(!handle)return null;
    if(!await permission(handle,false))throw new Error('Read permission for the portable folder was not granted.');
    try{const dataRoot=await getDataDirectory(handle,false);const fh=await dataRoot.getFileHandle('profile-data.json');const profile=JSON.parse(await (await fh.getFile()).text());if(!profile||!Array.isArray(profile.localLibrary))throw new Error('The selected folder contains an invalid profile-data.json file.');return profile}
    catch(e){if(e?.name==='NotFoundError')return null;throw e}
  }
  async function nativeReadProfile(rootPath){
    if(!nativePort)nativePort=chrome.runtime.connectNative(HOST);const port=nativePort;let offset=0,content='',found=false;
    try{while(true){const part=await nativeRequest(port,{action:'readFile',root:rootPath,path:'profile-data.json',offset,limit:120000});if(!part.found)return null;found=true;content+=part.content||'';if(part.eof)break;offset=part.nextOffset;if(!Number.isFinite(offset))throw new Error('Native helper returned an invalid file offset')}const profile=JSON.parse(content);if(!profile||!Array.isArray(profile.localLibrary))throw new Error('Native portable profile is invalid.');return profile}
    catch(e){if(!found&&/No such file|not found/i.test(e.message))return null;throw e}
  }
  async function readProfile(options={}){if(options.method==='folder')return readFolderProfile();const cfg=options.settings?{settings:options.settings}:await chrome.storage.local.get('settings');const settings=cfg.settings||{};const nativePath=String(settings.portableNativePath||'').trim();if(settings.portableNativeEnabled&&nativePath)return nativeReadProfile(nativePath);return readFolderProfile()}
  async function chooseFolder(){
    if(!window.showDirectoryPicker)throw new Error('Folder access is not supported in this Chrome version. Use the Native Messaging helper.');
    const h=await window.showDirectoryPicker({id:'charliemj-extension-root',mode:'readwrite'});
    if(!await permission(h))throw new Error('Write permission was not granted.');
    try{const mf=await h.getFileHandle('manifest.json');const manifest=JSON.parse(await (await mf.getFile()).text());if(manifest.name!=='Charlie MJ Tool Archive')throw new Error('The selected folder is not the Charlie MJ Tool Archive extension root.');}
    catch(e){if(e?.name==='NotFoundError')throw new Error('Select the exact unpacked Charlie MJ Tool Archive extension folder — the folder containing manifest.json, src, and data.');throw e;}
    await h.getDirectoryHandle('user-data',{create:true});
    await storeHandle(h);return `${h.name}/user-data`;
  }
  async function inspect(){const cfg=await chrome.storage.local.get('settings');const nativePath=String(cfg.settings?.portableNativePath||'').trim();if(cfg.settings?.portableNativeEnabled&&nativePath){if(!nativePort)nativePort=chrome.runtime.connectNative(HOST);return await nativeRequest(nativePort,{action:'inspect',root:nativePath})}const handle=await getHandle();if(!handle)return {ok:false,error:'No browser-authorized extension folder is connected'};if(!await permission(handle,false))return {ok:false,error:'Folder read permission is not granted'};const dataRoot=await getDataDirectory(handle,false);let profile=null,index=null;try{const pf=await dataRoot.getFileHandle('profile-data.json');profile=JSON.parse(await (await pf.getFile()).text())}catch{}try{const db=await dataRoot.getDirectoryHandle('database');const ix=await db.getFileHandle('category-index.json');index=JSON.parse(await (await ix.getFile()).text())}catch{}const missing=[];for(const item of index?.categories||[]){try{let dir=dataRoot;const parts=item.path.split('/');for(const part of parts.slice(0,-1))dir=await dir.getDirectoryHandle(part);await dir.getFileHandle(parts.at(-1))}catch{missing.push(item.path)}}const urls=new Set(),duplicates=[];for(const t of profile?.localLibrary||[]){const key=String(t.url||'').trim().toLowerCase().replace(/\/$/,'');if(key&&urls.has(key))duplicates.push(key);if(key)urls.add(key)}return {ok:true,profileTools:profile?.localLibrary?.length||0,indexCategories:index?.categories?.length||0,missingFiles:missing,duplicateUrls:duplicates,profilePresent:!!profile};}
  async function log(message,level='info'){const r=await chrome.storage.local.get('cmjPortableLog');const list=r.cmjPortableLog||[];list.unshift({at:Date.now(),level,message:String(message)});await chrome.storage.local.set({cmjPortableLog:list.slice(0,100)})}
  async function status(){const [handle,r,cfg]=await Promise.all([getHandle(),chrome.storage.local.get('cmjPortableSync'),chrome.storage.local.get('settings')]);let folder='Not selected';if(handle)folder=handle.name;else if(cfg.settings?.portableNativeEnabled&&cfg.settings?.portableNativePath)folder=cfg.settings.portableNativePath;return {folder,sync:r.cmjPortableSync||{status:'not-configured'},nativeAvailable:!!chrome.runtime.connectNative}}
  async function forgetFolder(){await clearHandle();await chrome.storage.local.set({cmjPortableSync:{status:'not-configured',lastSync:0,error:''}})}
  window.CMJPortable={sync,chooseFolder,readProfile,status,forgetFolder,makeFiles,inspect,log};
})();
